print("""
Bievenido a pete

Pete, es una herramienta que te ayuda a organizar mejor tu trabajo
desde un sistema de carpetas que permitiran un mejor seguimiento a lo
realizado en determinadas sesiones.
			

							   <Comandos disponibles>

mypete <carpeta principal o curso>			   Instala el programa y todos sus archivos

new <materia>              				       Dentro del folder de la materia especificada,
											   crea un folder del mes (si aun no ha sido registrado) 
											   y el dia en el cual fue escrito el comando.

open <materia> <mes> <dia>				       Abre la carpeta de la materia/mes/dia especificad@s.

show	           					      	   Enlista las materias registradas.

tree                                    	   Muestra las carpetas creadas hasta el momento.

add <materia> ...                              Para añadir una nueva materia.
											   Es posible añadir varias materias.

rnm <nuevo_nombre>							   Renombra la carpeta donde se encuentran nuestras
											   materias.
									
el <materia> ...							   Para eliminar la materia especificada	
											   Es posible añadir varias materias.

(beta) hor									   Muestra el contenido de hor.txt
""")