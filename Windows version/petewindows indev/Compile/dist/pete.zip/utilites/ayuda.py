print("\n\n\n\n\n  Bienvenido a C:\Pete> \n")
print("  C:\Pete> es una herramienta para organizar tus sesiones de trabajo. \n")
print("\n                           <Comandos disponibles>\n \n ")
print(" new <materia> ------------------------- Crea y abre una carpeta para una nueva sesion de trabajo.\n")
print(" open <materia> <mes> <dia> ------------ Abre la carpeta de la materia, mes o dia escrito/a. \n")
print(" show ---------------------------------- Enlista las materias registradas.\n")
print(" add <materia> <...> ------------------- Añade una nueva materia.")
print("                                         (Es posible añadir varias materias)\n")
print(" rnm <nuevo_nombre> <...> -------------- Renombra la carpeta del curso. \n")
print(" el <materia> <...> -------------------- Elimina la materia especificada")
print("                                         (Es posible eliminar varias materias.) \n")
print(" ayuda --------------------------------- Es un secreto ;).\n")


